//
//  RCLibMessageWrapper.h
//  RCE
//
//  Created by shaoshuai on 2021/6/21.
//

#import <Foundation/Foundation.h>
#import "RCVoiceRoomClientProtocol.h"

NS_ASSUME_NONNULL_BEGIN

@interface RCIMLibReceiver : NSObject <RCVoiceRoomClientProtocol>

@end

NS_ASSUME_NONNULL_END
