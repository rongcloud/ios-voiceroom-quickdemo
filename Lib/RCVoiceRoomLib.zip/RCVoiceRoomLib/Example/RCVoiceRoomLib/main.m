//
//  main.m
//  RCVoiceRoomLib
//
//  Created by zangqilong on 08/26/2021.
//  Copyright (c) 2021 zangqilong. All rights reserved.
//

@import UIKit;
#import "RCAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([RCAppDelegate class]));
    }
}
